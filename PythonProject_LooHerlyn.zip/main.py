#Title: PYTHON Project 
#Description:An application to analyse travellers’ trend.
#Name: <LooHerlyn>
#Group Name: <PythonIsASnake>
#Class: <PN2004K>
#Date: <23/02/2021>

import pandas as pd

class dataAnalysis :
  def __init__(self):
    dataFrame = pd.read_csv('ProjectData.csv')
    sortCountry(dataFrame)

def sortCountry(df) :

  print("There are " + str(len(df)) + " data rows read. \n")

  print("The following dataframe are read as follows: \n")
  print(df)

  CountryLabel = df.columns[20]
  print("\n\n"  " Europe Countries are selected.")

  print("The Europe Countries are sorted in ascending order. \n")
  sorted_df = df.sort_values(CountryLabel , ascending=[0])

  df = df.iloc[314:445, 20:30]
  print(df)

  visitors = []
  countries = []
  total_visitor = []
  country_dict = {}

  for country in df.columns[0:6]:
    countries.append(country)
    for visitor in df[country]:
      visitors.append(visitor)

  for i in range(0, len(visitors)):
    visitors[i] = int(visitors[i])
  numbers = len(visitors)
  counters = numbers / len(countries)

  index1 = 0
  index2 = int(counters)

  for country in range(0, len(countries)):
    total_visitor.append(sum(visitors[index1:index2]))
    index1 = index1 + int(counters)
    index2 = index2 + int(counters)

  country_dict = {
    countries[i]: total_visitor[i]
    for i in range(len(countries)) 
    }

    #sorting selected countries in descending order
  sort_visitor_dict = sorted(country_dict.items(),
    key=lambda x: x[1], 
    reverse=True)

  country_dict = dict(sort_visitor_dict)

    #to list contents of variable using DataFrame
  df = pd.DataFrame(list(country_dict.items()),
    columns=['Country', 'Visitors'])
  print("\n Top 3 Europe Countries \n")
  print(df)

if __name__ == '__main__':

  #Project Title
  print('Data Analysis - PYTHON Project ')

  dataAnalysis()